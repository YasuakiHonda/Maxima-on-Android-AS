#!/system/bin/sh

# Copyright 2015 Yasuaki Honda (yasuaki.honda@gmail.com)
# This file is part of MaximaOnAndroid.
#
# MaximaOnAndroid is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
 
# MaximaOnAndroid is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with MaximaOnAndroid.  If not, see <http://www.gnu.org/licenses/>.

gnuplot_dir=/data/data/jp.yhonda/files/additions/gnuplot/bin

# $gnuplot_dir/gnuplot -V > /dev/null 2>&1
$gnuplot_dir/gnuplot -V >> /data/data/jp.yhonda/files/test.log 2>&1
case "$?" in
  0) echo "arm"; exit 0;;
esac

# $gnuplot_dir/gnuplot.x86 -V > /dev/null 2>&1
$gnuplot_dir/gnuplot.x86 -V >> /data/data/jp.yhonda/files/test.log 2>&1
case "$?" in
  0) echo "x86"; exit 0;;
esac

echo "not supported"
exit 1
